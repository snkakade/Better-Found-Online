import {QueryClient,QueryClientProvider} from "@tanstack/react-query";
import {Outlet,createRootRouteWithContext,HeadContent,Scripts} from "@tanstack/react-router";
import {useEffect,type ReactNode} from "react";
import appCss from "../styles.css?url";
import meta from "../app-meta.json";
import {scrollScrubTheme} from "../scroll-scrub-scenes";
const url="https://better-found-online.higgsfield.app";
export const Route=createRootRouteWithContext<{queryClient:QueryClient}>()({
head:()=>({meta:[{charSet:"utf-8"},{name:"viewport",content:"width=device-width, initial-scale=1"},{title:meta.og_title},{name:"description",content:meta.og_description},{name:"theme-color",content:scrollScrubTheme.background},{property:"og:title",content:meta.og_title},{property:"og:description",content:meta.og_description},{property:"og:type",content:"website"},{property:"og:url",content:url},{property:"og:image",content:url+"/assets/brand/og.jpg"},{name:"twitter:card",content:"summary_large_image"},{name:"twitter:image",content:url+"/assets/brand/og.jpg"}],links:[{rel:"stylesheet",href:appCss},{rel:"icon",href:"/favicon.ico"},{rel:"icon",type:"image/png",sizes:"32x32",href:"/assets/brand/icon-32.png"},{rel:"apple-touch-icon",href:"/assets/brand/icon-180.png"},{rel:"manifest",href:"/site.webmanifest"},{rel:"canonical",href:url},{rel:"preload",href:"/assets/fonts/Outfit.ttf",as:"font",type:"font/ttf",crossOrigin:"anonymous"}]}),
shellComponent:Shell,component:Root,notFoundComponent:()=> <main className="error-page"><h1>Not found.<br/>Let’s get you back.</h1><a href="/">Back to home ↗</a></main>,
errorComponent:()=> <main className="error-page"><h1>Something didn’t load.</h1><a href="/">Try again ↗</a></main>
});
function Shell({children}:{children:ReactNode}){return <html lang="en-GB"><head><HeadContent/></head><body>{children}<script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify({"@context":"https://schema.org","@type":"Organization",name:"Better Found Online",url,telephone:"+1-570-707-7078",logo:url+"/assets/brand/icon-512.png",description:meta.og_description,hasOfferCatalog:{"@type":"OfferCatalog",name:"Digital services",itemListElement:["Website design and digital experiences","SEO and generative engine optimisation","CRM and workflow automation","Business process mapping and reporting"].map(name=>({"@type":"Offer",itemOffered:{"@type":"Service",name}}))}})}}/><Scripts/></body></html>}
declare const __HF_DESIGN_INSPECTOR__: boolean;
function Root(){useEffect(()=>{if(__HF_DESIGN_INSPECTOR__)void import("../module/design-inspector/runtime").then(m=>m.installHiggsfieldDesignInspector()).catch(()=>{});},[]);const {queryClient}=Route.useRouteContext();return <QueryClientProvider client={queryClient}><Outlet/></QueryClientProvider>}
