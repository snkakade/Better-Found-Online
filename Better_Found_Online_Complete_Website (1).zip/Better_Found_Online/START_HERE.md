# Better Found Online: complete website
This archive contains the complete React 19 + TanStack Start website source and all files tracked in the final deployed project.

## Run locally
Install Node.js 22 or newer and Bun.
From a terminal in this folder:
    cd app
    bun install --frozen-lockfile
    bun run dev
Open the localhost URL printed by Vite. Do not open the TSX files directly in a browser.

## Validate and build
    bun run typecheck
    bun run build
Build output is app/dist/client (assets) and app/dist/server/server.js (Cloudflare Worker SSR entry).
This is an SSR application, not a single HTML file. Deploy the server and client assets together using a compatible Cloudflare Worker deployment. Uploading only dist/client does not deploy the full application.
app/wrangler.jsonc and app/app.manifest.json contain the starter deployment configuration; review them for your own Cloudflare account and bindings. No account credentials are included.

## Main editable files
- app/src/routes/index.tsx: homepage copy, navigation, services, Insights and contact details.
- app/src/bfo.css: brand styles, responsive layouts and logo animation.
- app/src/routes/__root.tsx: HTML shell, metadata and structured data.
- app/src/scroll-scrub-scenes.ts: About-section film and chapter.
- app/src/components/scroll-scrub/: scroll-controlled media engine.
- app/src/app-meta.json: title and social metadata.
- app/public/assets/: all production images, local fonts, logo, icons and videos.
- app/public/site.webmanifest, robots.txt, sitemap.xml: browser and search configuration.

## Domain and hosting
The current metadata uses https://better-found-online.higgsfield.app.
When moving to betterfoundonline.com, replace the old origin in __root.tsx, app-meta.json, robots.txt and sitemap.xml.
The observed Higgsfield sign-in requirement was imposed by hosting, not by this homepage. Local development does not require Higgsfield sign-in.
The scaffold retains unused platform routes and vendored packages for build compatibility. Do not remove them without checking imports, route generation and the build. The homepage does not call AI-generation services.

## Included assets
Production: optimised WebP images; supplied logo, favicon sizes and social images; local Outfit and IBM Plex Mono fonts; exact video poster frames; 1080p desktop and 540p mobile loops.
The supplied video was 1280x720. Desktop output was upscaled to 1920x1080; it is not native 1080p detail. Forward/reverse encoding makes the loop return to its starting frame.
Original user uploads are in original-assets/ when available.
Third-party source notices and package manifests are retained in app/packages.

## Checks performed
Typecheck and production build passed.
Local desktop/mobile checks confirmed video autoplay/mute/loop, three transform parallax depths, contact link destinations, expandable Insights, mobile menu, no horizontal overflow and no JavaScript errors.
Reduced-motion testing found no video elements.
Live anonymous verification was blocked by Higgsfield hosting sign-in.
Reviews, hours, address, prices and client results were not supplied and were not invented.
